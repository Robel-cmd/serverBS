# these four roles or rank are the only ones that work.
vipHashes = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
co = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
owner = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
adminHashes = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]

# previous creater made these two roles, they don't have any used in the game they can me used as tags.
elder = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
member = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]

# The previous creater left these as Tags you can put on players(check the admin.py).
assholes = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
chutiya = ['\xee\x80\xb0Android ID', "\xee\x80\xa0Google play games ID", "\xee\x80\xa0PC ID"]
