# coding=utf-8
from bsSpaz import *

###by: Infinite###

t = Appearance("MJ")

t.colorTexture = "frostyColor"
t.colorMaskTexture = "agentIconColorMask"

t.iconTexture = "jokerIcon"
t.iconMaskTexture = "jokerIconColorMask"

t.headModel = "frostyHead"
t.torsoModel = "agentTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "bearForeArm"
t.handModel = "bearHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

penguinSounds = ['agent1', 'agent2', 'agent3', 'agent4']
penguinHitSounds = ['agentHit1', 'agentHit2']

t.attackSounds = aliSounds
t.jumpSounds = bunnySounds
t.impactSounds = agentHitSounds
t.deathSounds = ["pixieDeath"]
t.pickupSounds = agentSounds
t.fallSounds = ["agentFall"]

t.style = 'agent'