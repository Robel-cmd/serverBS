##########`These files were from TheGreat`##########
##########`Files were modify by system32`##########


# if need to translate copy all the text and translate to your langua :)

Hello my nickname is system32 :) and I'll be helping you build your own server today.

	first thing you'll need to do is go to the script orfile named "config.py" I'll recomend opeing the file right now
	and keeping these open as well. I'll try and explain everything really fast for you to understand everything.

# config.py #
	Once in the file you'll see that some lines have already added for you and also in some lines it explain what each one does
	the most importan one is the port you'll need to check what the port is for your server and change is need toif not lt it be.
	Add your own playlist to it and change the mod "ffa" or "teams" some if the play list you might want to used might not work so
	try using the same scripts and created one using the scripts on date.
	
# Errors
	Some of the errors you might see in the consol might be the tnt problem these might show up if your using a free server and not a paid one
	so just let it be.
	
# bsSpaz ._?
	As you can see there is a bsSpaz in the begingin an not in the script file well thats because there's two bsSpaz file the one in scripts DOES NOT HVE 
	TRIPLE PUNCH ON IT and the one in the beging files has triple punch in it. I added these file here becuase lots of new creater only do it for the Super Smash FFA
	so depending of what your making change the files. There is one error and that is if you do change the bsSpaz AKA the one with triple on it the stats or won't work and thats
	becuase that bsSpaz with triple is and old file.
	
# Modify 
	These files are all in scripts folder###
	There are some powerups that don't work with the bsSpaz with triple so you might need to fix that so they don't spawn in the middle of the game these by putting a 0 
	here is and example
		` ('impactBombs', 3), `
		` ('impactBombs', 0), ` If you change it to a 0 the powerup will not show or spawn in the server no more
	
# Chat Commands
	There three files with these name "chatCmd you can take a look at them but the one that is more problematic is the ChatCmd2.py becuase those commads every one can used them
	and the problem is that they will start spamming the chat with it. The only two you need to lookup to are /help and /rules
	you can change the text for something else like /Y==CD+ something like that something that other player never find out.
	
# Nigh mode
	too add night mode you'll need to go do Maps.py and search for the map you want in night mode 
	serach these up `bsGlobals.tint =` and change the color inside the () to 0.60, 0.80, 1.23 it would look like these `bsGlobals.tint = (0.60 ,0.80, 1.23)`
	
# getPermissionsHashes.py
	These fileis is for adding roles (owner, admin, vip....)  I left some readings in there that will helpyou find out wich ones works.
	It starts with android id, google id, pc id, the pc id does not worked :(
	you can only add android and google play id these files only accept does id it does not work with the pb- ids
	you cannot add google play id with fancy leters or simbol on it it has to have normal letter.
	
# Settings.py
	In these file you'll fine lots of trues and False you decide wich ones to keep True
	stats will only work in a paid server that also goes for the /me or /stats and if you have a paid server but added the old bsSpaz.py AKA the one with triple punch the stats will not work correctly
	
# create your own character using the next lines of code 
	start copying from the #coding=utf-u to style all of it and create a new file and saveAS test.py

# coding=utf-8
from bsSpaz import *

###by: systm32/Infinite###

t = Appearance("MJ")

t.colorTexture = "frostyColor"
t.colorMaskTexture = "agentIconColorMask"

t.iconTexture = "jokerIcon"
t.iconMaskTexture = "jokerIconColorMask"

t.headModel = "frostyHead"
t.torsoModel = "agentTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "bearForeArm"
t.handModel = "bearHand"
t.upperLegModel = "agentUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "agentToes"

penguinSounds = ['agent1', 'agent2', 'agent3', 'agent4']
penguinHitSounds = ['agentHit1', 'agentHit2']

t.attackSounds = aliSounds
t.jumpSounds = bunnySounds
t.impactSounds = agentHitSounds
t.deathSounds = ["pixieDeath"]
t.pickupSounds = agentSounds
t.fallSounds = ["agentFall"]

t.style = 'agent'
	
	
	if you need help building your own character join the discord below and dm for help 
	
	
"I hope these files help you build a normal server if you need any more help please join my discord `https://discord.gg/sC3vxwVqvS`"
"these files only work in the 1.4 verson."
""