# place any of your own overrides here.
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
config['partyName'] = 'NameOfTheServer'
config['port'] = 43210
config['maxPartySize'] = 7

config['partyIsPublic'] = True
config['language'] = 'English'
config['playlistShuffle'] = True
config['playlistCode'] = 1242
config['autoBalanceTeams'] = True
# check out the bsTeamGame.py to change the teams name and color.
# check out the bsFlag.py to change the flags Icone/image.
config['sessionType'] = 'teams'

# Series length in teams mode (7 == 'best-of-7' series; a team must get 4 wins)
config['teamsSeriesLength'] = 7

# Points to win in free-for-all mode (Points are awarded per game based on
# performance)
config['ffaSeriesScoreToWin'] = 24

# If you provide a custom stats webpage for your server, you can use
# this to provide a convenient in-game link to it in the server-browser
# beside the server name.
# if ${ACCOUNT} is present in the string, it will be replaced by the
# currently-signed-in account's id.  To get info about an account,
# you can use the following url:
# http://bombsquadgame.com/accountquery?id=ACCOUNT_ID_HERE
config['statsURL'] = ''
# These is the stats button that will show in the gather online servers. You can put any type
# of link in it for example, the link to join your discord server to increase it.